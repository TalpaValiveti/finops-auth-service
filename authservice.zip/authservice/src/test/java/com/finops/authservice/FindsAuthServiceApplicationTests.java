package com.finops.authservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FindsAuthServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
