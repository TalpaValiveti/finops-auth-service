package com.finops.authservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FindsAuthServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FindsAuthServiceApplication.class, args);
	}

}
